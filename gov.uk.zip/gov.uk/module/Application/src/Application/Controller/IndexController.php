<?php

/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2015 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

class IndexController extends AbstractActionController {

    protected $application_table;

    public function indexAction() {
        $sm = $this->getServiceLocator();
        $application = $sm->get(\Application\Model\ApplicationTable::class);

        $pages = [
            [
                'href' => '/gov.uk/public/application/index',
                'label' => 'Home'
            ]
        ];

        return new ViewModel([
            'pages' => $pages,
            'applications' => $this->getApplicationTable()->fetchAll()
        ]);
    }

    public function editAction() {
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toUrl('/gov.uk/public/application/index');
        }

        // Get the Application with the specified id.  An exception is thrown
        // if it cannot be found, in which case go to the index page.
        try {
            $application = $this->getApplicationTable()->getApplication($id);
        } catch (\Exception $ex) {
            return $this->redirect()->toUrl('/gov.uk/public/application/index');
        }

        $form = new \Application\Form\ApplicationForm();
        $form->bind($application);
        $form->get('submit')->setAttribute('value', 'Edit');

        $request = $this->getRequest();
        if ($request->isPost()) {
            $form->setInputFilter($application->getInputFilter());
            $form->setData($request->getPost());

            if ($form->isValid()) {
                $this->getApplicationTable()->saveApplication($application);

                // Redirect to list of applications
                return $this->redirect()->toUrl('/gov.uk/public/application/index/view/' . $application->application_id);
            }
        }

        $pages = [
            [
                'href' => '/gov.uk/public/application/index',
                'label' => 'Home'
            ],
            [
                'href' => '/gov.uk/public/application/index/view',
                'label' => 'Edit An Application'
            ]
        ];

        return new ViewModel([
            'pages' => $pages,
            'id' => $id,
            'form' => $form,
        ]);
    }

    public function viewAction() {
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toUrl('/gov.uk/public/application/index');
        }

        // Get the Application with the specified id.  An exception is thrown
        // if it cannot be found, in which case go to the index page.
        try {
            $application = $this->getApplicationTable()->getApplication($id);
        } catch (\Exception $ex) {
            return $this->redirect()->toUrl('/gov.uk/public/application/index');
        }

        $pages = [
            [
                'href' => '/gov.uk/public/application/index',
                'label' => 'Home'
            ],
            [
                'href' => '/gov.uk/public/application/index/view',
                'label' => 'View Application'
            ]
        ];

        return new ViewModel([
            'pages' => $pages,
            'application' => $application,
        ]);
    }
    
    public function deleteAction() {
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toUrl('/gov.uk/public/application/index');
        }

        // Get the Application with the specified id.  An exception is thrown
        // if it cannot be found, in which case go to the index page.
        try {
            $application = $this->getApplicationTable()->getApplication($id);
        } catch (\Exception $ex) {
            return $this->redirect()->toUrl('/gov.uk/public/application/index');
        }

        $this->getApplicationTable()->deleteApplication($id);
        return $this->redirect()->toUrl('/gov.uk/public/application/index');
    }

    public function addAction() {
        $form = new \Application\Form\ApplicationForm();
        $form->get('submit')->setValue('Add');

        $request = $this->getRequest();
        if ($request->isPost()) {
            $application = new \Application\Model\Application();
            $form->setInputFilter($application->getInputFilter());
            $form->setData($request->getPost());

            if ($form->isValid()) {
                $application->exchangeArray($form->getData());
                $this->getApplicationTable()->saveApplication($application);

                return $this->redirect()->toUrl('/gov.uk/public/application/index');
            }
        }

        $pages = [
            [
                'href' => '/gov.uk/public/application/index',
                'label' => 'Home'
            ],
            [
                'href' => '/gov.uk/public/application/index/view',
                'label' => 'Create Application'
            ]
        ];

        return new ViewModel([
            'pages' => $pages,
            'form' => $form
        ]);
    }

    public function getApplicationTable() {
        if (!$this->application_table) {
            $sm = $this->getServiceLocator();
            $this->application_table = $sm->get('Application\Model\ApplicationTable');
        }
        return $this->application_table;
    }

}
