<?php

namespace Application\Form;

 use Zend\Form\Form;

 class ApplicationForm extends Form
 {
     public function __construct($name = null)
     {
         // we want to ignore the name passed
         parent::__construct('application');

         $this->add(array(
             'name' => 'application_id',
             'type' => 'Hidden',
         ));
         $this->add(array(
             'name' => 'first_name',
             'type' => 'Text',
             'options' => array(
                 'label' => 'First Name:',
             ),
         ));
         $this->add(array(
             'name' => 'last_name',
             'type' => 'Text',
             'options' => array(
                 'label' => 'Last Name:',
             ),
         ));
         $this->add(array(
             'name' => 'date_of_birth',
             'type' => 'Date',
             'options' => array(
                 'label' => 'Date of Birth:',
             ),
         ));
         $this->add(array(
             'name' => 'information',
             'type' => 'Textarea',
             'options' => array(
                 'label' => 'Information: (For the purpose of this demonstration, HTML tags are allowed)',
             ),
             'attributes' => [
                 'rows' => 24,
             ]
         ));
         $this->add(array(
             'name' => 'submit',
             'type' => 'Submit',
             'attributes' => array(
                 'value' => 'Go',
                 'id' => 'submitbutton',
             ),
         ));
     }
 }