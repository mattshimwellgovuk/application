<?php

 namespace Application\Model;

 class Application implements \Zend\InputFilter\InputFilterAwareInterface
 {
     public $application_id;
     public $first_name;
     public $last_name;
     public $date_of_birth;
     public $information;
     protected $input_filter; 

     public function exchangeArray($data)
     {
         $this->application_id     = (!empty($data['application_id'])) ? $data['application_id'] : null;
         $this->first_name     = (!empty($data['first_name'])) ? $data['first_name'] : null;
         $this->last_name     = (!empty($data['last_name'])) ? $data['last_name'] : null;
         $this->date_of_birth     = (!empty($data['date_of_birth'])) ? $data['date_of_birth'] : null;
         $this->information     = (!empty($data['information'])) ? $data['information'] : null;
     }

     // Add content to these methods:
     public function setInputFilter(\Zend\InputFilter\InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
     
     public function getArrayCopy()
     {
         return get_object_vars($this);
     }

     public function getInputFilter()
     {
         if (!$this->input_filter) {
             $input_filter = new \Zend\InputFilter\InputFilter();

             $input_filter->add(array(
                 'name'     => 'application_id',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'Int'),
                 ),
             ));

             $input_filter->add(array(
                 'name'     => 'first_name',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 1,
                             'max'      => 255,
                         ),
                     ),
                 ),
             ));

             $input_filter->add(array(
                 'name'     => 'last_name',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 1,
                             'max'      => 255,
                         ),
                     ),
                 ),
             ));

             $input_filter->add(array(
                 'name'     => 'date_of_birth',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
             ));

             $input_filter->add(array(
                 'name'     => 'information',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 1,
                             'max'      => 65000,
                         ),
                     ),
                 ),
             ));


             $this->input_filter = $input_filter;
         }

         return $this->input_filter;
     }
 }