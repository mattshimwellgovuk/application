<?php

namespace Application\Model;

use Zend\Db\TableGateway\TableGateway;

class ApplicationTable {

    protected $tableGateway;

    public function __construct(TableGateway $tableGateway) {
        $this->tableGateway = $tableGateway;
    }

    public function fetchAll() {
        $resultSet = $this->tableGateway->select();
        return $resultSet;
    }

    public function getApplication($id) {
        $application_id = (int) $id;
        $rowset = $this->tableGateway->select(array('application_id' => $application_id));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $application_id");
        }
        return $row;
    }

    public function saveApplication(Application $application) {
        $data = array(
            'first_name' => $application->first_name,
            'last_name' => $application->last_name,
            'date_of_birth' => $application->date_of_birth,
            'information' => $application->information,
        );

        $application_id = (int) $application->application_id;
        if ($application_id == 0) {
            $this->tableGateway->insert($data);
        } else {
            if ($this->getApplication($application_id)) {
                $this->tableGateway->update($data, array('application_id' => $application_id));
            } else {
                throw new \Exception('Application application_id does not exist');
            }
        }
    }

    public function deleteApplication($application_id) {
        $this->tableGateway->delete(array('application_id' => (int) $application_id));
    }

}
