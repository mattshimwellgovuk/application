<?php
$directory = "public/scss/";

require 'init_autoloader.php';

$scss = new scssc();

$scss->addImportPath('vendor/alphagov/govuk_frontend_toolkit/stylesheets');
        
$server = new scss_server($directory, null, $scss);
$server->serve();